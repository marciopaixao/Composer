<?php

return [
	'appVersion' => '5.3.12',
	'patchVersion' => '2020.03.24',
	'lib_roundcube' => '0.0.87'
];
