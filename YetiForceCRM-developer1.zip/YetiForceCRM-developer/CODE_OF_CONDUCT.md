# CODE OF CONDUCT
We prepared a very short and easy to follow CODE OF CONDUCT. If you want to be a member of our community, please follow these simple guidelines.

## ✔BE KIND, PATIENT, AND TOLERANT
Remember that all of us had to start learning at some point.

## ✔RESPECT OTHERS AND THEIR CONTRIBUTIONS
the same way you want them to respect you and your contributions.

## ✔REMEMBER THAT NOT EVERYBODY IS FLUENT IN ENGLISH
Short answers do not necessarily mean that the person who answered is rude, they might mean that despite the language barrier they still want to help you.

## ✔BE RESPONSIBLE AND CONSIDERATE
Remember that your contribution will be used by people all around the world, who will depend on its reliability.

## ✔CHOOSE YOUR WORDS CAREFULLY AND DON’T INSULT
Insults and verbal abuse towards other community members will not be tolerated.

## ✔REMEMBER THAT WE ALL HAVE DIFFERENT OPINIONS
We do not all think alike, and everyone is entitled to their opinion. You cannot force people to agree with you, what you can do is convince them by presenting reasonable arguments that prove why your idea is great. Blaming others will not lead anywhere. Try to understand why that person has a different opinion.

❗If you would like to report someone for violating our code of conduct, please send an email to help@yetiforce.com❗

## THANK YOU!
