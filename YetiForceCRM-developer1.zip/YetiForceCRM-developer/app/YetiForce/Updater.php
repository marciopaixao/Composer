<?php
/**
 * YetiForce updater class.
 *
 * @package   App
 *
 * @copyright YetiForce Sp. z o.o
 * @license   YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @author    Mariusz Krzaczkowski <m.krzaczkowski@yetiforce.com>
 */

namespace App\YetiForce;

/**
 * YetiForce updater class.
 */
class Updater
{
	/**
	 * System version for updates.
	 *
	 * @var string
	 */
	private static $version = '';

	/**
	 * Get list of available updates.
	 *
	 * @return array
	 */
	public static function get(): array
	{
		$fullVer = \explode('.', \App\Version::get());
		array_pop($fullVer);
		self::$version = \implode('.', $fullVer);
		$file = \ROOT_DIRECTORY . '/app_data/SystemUpdater.json';
		if (\file_exists($file) && filemtime($file) > strtotime('-5 minute')) {
			return \App\Json::read($file);
		}
		$return = [];
		$updaterMode = \Config\Developer::$updaterDevMode ? 'developer' : 'master';
		try {
			$url = "https://github.com/YetiForceCompany/UpdatePackages/raw/{$updaterMode}/YetiForce%20CRM%20{$fullVer[0]}.x.x/Updater.json";
			$response = (new \GuzzleHttp\Client(\App\RequestHttp::getOptions()))->request('GET', $url);
			if (200 !== $response->getStatusCode()) {
				throw new \App\Exceptions\AppException('Error with connection |' . $response->getStatusCode());
			}
			$body = $response->getBody();
			$body = \App\Json::isEmpty($body) ? [] : \App\Json::decode($body);
			if ($body && isset($body[self::$version])) {
				$return = $body[self::$version];
				\App\Json::save($file, $return);
			}
		} catch (\Throwable $ex) {
			\App\Log::warning('Error - ' . __CLASS__ . ' - ' . $ex->getMessage());
		}
		return $return;
	}

	/**
	 * Get updates to install.
	 *
	 * @return array
	 */
	public static function getToInstall(): array
	{
		$data = self::get();
		if (\Config\Developer::$updaterDevMode) {
			$where = ['like', 'from_version',  self::$version . '.%', false];
		} else {
			$where = ['from_version' => \App\Version::get()];
			foreach ($data as $key => $row) {
				if ($row['fromVersion'] !== \App\Version::get()) {
					unset($data[$key]);
				}
			}
		}
		$query = (new \App\Db\Query())->from('yetiforce_updates')->where($where);
		$dataReader = $query->createCommand()->query();
		$updates = [];
		foreach ($dataReader as $row) {
			$updates[$row['name']] = $row;
		}
		foreach ($data as $key => &$row) {
			$row['hash'] = \md5($row['label']);
			if (isset($updates[$row['label']])) {
				unset($data[$key]);
			}
		}
		return $data;
	}

	/**
	 * Check if the package has been downloaded.
	 *
	 * @param string[] $package
	 *
	 * @return bool
	 */
	public static function isDownloaded(array $package): bool
	{
		return \file_exists(ROOT_DIRECTORY . \DIRECTORY_SEPARATOR . \Settings_ModuleManager_Module_Model::getUploadDirectory() . \DIRECTORY_SEPARATOR . $package['hash'] . '.zip');
	}

	/**
	 * Download package.
	 *
	 * @param string[] $package
	 *
	 * @return void
	 */
	public static function download(array $package)
	{
		try {
			$uploadDir = \Settings_ModuleManager_Module_Model::getUploadDirectory();
			$path = ROOT_DIRECTORY . \DIRECTORY_SEPARATOR . $uploadDir . \DIRECTORY_SEPARATOR . $package['hash'] . '.zip';
			$url = $package['url'];
			if (\Config\Developer::$updaterDevMode) {
				$url = \str_replace('raw/master', 'raw/developer', $url);
			}
			(new \GuzzleHttp\Client(\App\RequestHttp::getOptions()))->request('GET', $url, ['sink' => $path]);
		} catch (\Throwable $ex) {
			\App\Log::warning('Error - ' . __CLASS__ . ' - ' . $ex->getMessage());
		}
	}
}
